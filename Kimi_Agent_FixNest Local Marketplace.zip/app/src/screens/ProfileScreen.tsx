import { User, MapPin, Bell, HelpCircle, FileText, LogOut, ChevronRight, Heart, Shield } from 'lucide-react';

interface MenuItem {
  icon: React.ElementType;
  label: string;
  subtitle?: string;
  danger?: boolean;
}

const menuSections: { title: string; items: MenuItem[] }[] = [
  {
    title: 'Account',
    items: [
      { icon: User, label: 'Personal Info', subtitle: 'Name, phone, email' },
      { icon: MapPin, label: 'Saved Addresses', subtitle: 'Manage locations' },
      { icon: Bell, label: 'Notifications', subtitle: 'Push, SMS, Email' },
    ],
  },
  {
    title: 'Support',
    items: [
      { icon: HelpCircle, label: 'Help Center' },
      { icon: FileText, label: 'Terms & Privacy' },
      { icon: Shield, label: 'Safety Center' },
    ],
  },
  {
    title: 'More',
    items: [
      { icon: Heart, label: 'Saved Providers' },
      { icon: LogOut, label: 'Log Out', danger: true },
    ],
  },
];

export default function ProfileScreen() {
  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto no-scrollbar bg-surface">
        {/* Header */}
        <div className="bg-white px-4 py-6 border-b border-gray-200">
          <h1 className="font-heading font-bold text-xl text-text-primary">Account</h1>
        </div>

        {/* User Profile Card */}
        <div className="bg-white px-5 py-6">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-teal-light flex items-center justify-center">
              <User size={28} className="text-teal" />
            </div>
            <div>
              <h2 className="font-heading font-semibold text-lg text-text-primary">Guest User</h2>
              <p className="text-text-secondary text-sm">+91 98765 43210</p>
              <div className="flex items-center gap-1 mt-1">
                <Shield size={12} className="text-teal" />
                <span className="text-teal text-xs font-medium">Verified</span>
              </div>
            </div>
          </div>
        </div>

        {/* Menu Sections */}
        {menuSections.map((section) => (
          <div key={section.title} className="mt-3 bg-white">
            <div className="px-5 pt-4 pb-2">
              <h3 className="text-xs font-semibold text-text-muted uppercase tracking-wide">
                {section.title}
              </h3>
            </div>
            <div className="px-2 pb-2">
              {section.items.map((item, index) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.label}
                    className={`w-full flex items-center gap-3 px-3 py-3.5 rounded-xl transition-colors ${
                      item.danger ? 'text-red-500' : 'text-text-primary'
                    } ${index < section.items.length - 1 ? 'border-b border-gray-50' : ''}`}
                  >
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${
                      item.danger ? 'bg-red-50' : 'bg-gray-50'
                    }`}>
                      <Icon size={18} className={item.danger ? 'text-red-500' : 'text-text-secondary'} />
                    </div>
                    <div className="flex-1 text-left">
                      <p className={`text-sm font-medium ${item.danger ? 'text-red-500' : 'text-text-primary'}`}>
                        {item.label}
                      </p>
                      {item.subtitle && (
                        <p className="text-text-muted text-xs mt-0.5">{item.subtitle}</p>
                      )}
                    </div>
                    <ChevronRight size={16} className="text-text-muted" />
                  </button>
                );
              })}
            </div>
          </div>
        ))}

        {/* App Version */}
        <div className="py-8 text-center">
          <p className="text-text-muted text-xs">FixNest v1.0.0</p>
          <p className="text-text-muted text-xs mt-1">Made with care in India</p>
        </div>
      </div>
    </div>
  );
}
