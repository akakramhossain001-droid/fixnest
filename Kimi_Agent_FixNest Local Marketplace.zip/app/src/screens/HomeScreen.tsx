import { useState, useMemo, useRef, useEffect } from 'react';
import { Search, SlidersHorizontal, X, Wrench, Zap, BookOpen, Sparkles, ChevronDown, ArrowRight } from 'lucide-react';
import type { Category, Provider } from '@/types';
import { categories, sortOptions, providers as allProviders } from '@/data/providers';
import ProviderCard from '@/components/ProviderCard';
import BookingSheet from '@/components/BookingSheet';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const iconMap: Record<string, React.ElementType> = {
  Wrench, Zap, BookOpen, Sparkles,
};

interface HomeScreenProps {
  onNavigateToProfile: (providerId: string) => void;
}

export default function HomeScreen({ onNavigateToProfile }: HomeScreenProps) {
  const [activeCategory, setActiveCategory] = useState<Category>('plumber');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState('recommended');
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [expandedCardId, setExpandedCardId] = useState<string | null>(null);
  const [bookingProvider, setBookingProvider] = useState<Provider | null>(null);
  const [showBottomBar, setShowBottomBar] = useState(false);
  const listRef = useRef<HTMLDivElement>(null);
  const sortDropdownRef = useRef<HTMLDivElement>(null);

  // Filter and sort providers
  const filteredProviders = useMemo(() => {
    let result = allProviders.filter((p) => p.category === activeCategory);

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q)) ||
          p.location.toLowerCase().includes(q)
      );
    }

    switch (sortBy) {
      case 'price-low':
        result = [...result].sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result = [...result].sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result = [...result].sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }

    return result;
  }, [activeCategory, searchQuery, sortBy]);

  // Show bottom bar after scrolling past first 2 cards
  useEffect(() => {
    const handleScroll = () => {
      setShowBottomBar(window.scrollY > 200);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close sort dropdown on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (sortDropdownRef.current && !sortDropdownRef.current.contains(e.target as Node)) {
        setShowSortDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  const handleBook = (provider: Provider) => {
    setBookingProvider(provider);
  };

  const handleConfirmBooking = (_bookingData: Omit<import('@/types').Booking, 'id' | 'status'>) => {
    // In a real app, this would send to backend
    setBookingProvider(null);
    setExpandedCardId(null);
    // Show success (could add toast here)
  };

  const activeSortLabel = sortOptions.find((o) => o.value === sortBy)?.label || 'Recommended';

  return (
    <div className="flex flex-col h-full">
      {/* Scrollable content */}
      <div className="flex-1 overflow-y-auto no-scrollbar dot-pattern bg-surface" ref={listRef}>
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white border-b border-gray-200">
          <div className="flex items-center justify-between px-4 h-14">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-teal flex items-center justify-center">
                <Wrench size={16} className="text-white" />
              </div>
              <span className="font-heading font-bold text-lg text-text-primary">FixNest</span>
            </div>
            <div className="flex items-center gap-3">
              <button className="text-sm text-text-secondary font-medium">Login</button>
              <button className="text-sm text-teal font-semibold border border-teal px-3 py-1.5 rounded-lg">
                Sign Up
              </button>
            </div>
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-1 px-4 py-2 overflow-x-auto no-scrollbar">
            {categories.map((cat) => {
              const Icon = iconMap[cat.icon];
              const isActive = activeCategory === cat.id;
              return (
                <button
                  key={cat.id}
                  onClick={() => {
                    setActiveCategory(cat.id);
                    setExpandedCardId(null);
                  }}
                  className={`flex flex-col items-center justify-center min-w-[72px] py-2 px-3 rounded-xl transition-all duration-200 ${
                    isActive
                      ? 'bg-teal-light text-teal'
                      : 'text-text-secondary hover:bg-gray-50'
                  }`}
                >
                  <Icon size={22} strokeWidth={isActive ? 2.5 : 1.5} />
                  <span className={`text-[11px] mt-1 font-medium ${isActive ? 'text-teal' : ''}`}>
                    {cat.label}
                  </span>
                  {isActive && (
                    <div className="w-6 h-0.5 bg-teal rounded-full mt-1" />
                  )}
                </button>
              );
            })}
          </div>
        </header>

        {/* Search + Filter Bar */}
        <div className="px-4 pt-4 pb-2 space-y-3 bg-surface">
          {/* Search input */}
          <div className="flex items-center gap-2">
            <div className="flex-1 flex items-center gap-2 bg-white border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-teal transition-colors">
              <Search size={18} className="text-text-muted flex-shrink-0" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search for a service..."
                className="flex-1 bg-transparent text-sm text-text-primary placeholder:text-text-muted outline-none"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')}>
                  <X size={16} className="text-text-muted" />
                </button>
              )}
            </div>
            <button className="w-10 h-10 bg-teal rounded-xl flex items-center justify-center flex-shrink-0 active:scale-95 transition-transform">
              <Search size={18} className="text-white" />
            </button>
          </div>

          {/* Sort + Category chip */}
          <div className="flex items-center gap-2">
            {/* Sort dropdown */}
            <div className="relative" ref={sortDropdownRef}>
              <button
                onClick={() => setShowSortDropdown(!showSortDropdown)}
                className="flex items-center gap-1.5 bg-white border border-gray-200 rounded-xl px-3 py-2 text-sm text-text-primary"
              >
                <SlidersHorizontal size={14} className="text-text-secondary" />
                <span>{activeSortLabel}</span>
                <ChevronDown size={14} className={`text-text-secondary transition-transform ${showSortDropdown ? 'rotate-180' : ''}`} />
              </button>

              {showSortDropdown && (
                <div className="absolute top-full left-0 mt-1 bg-white border border-gray-200 rounded-xl shadow-lg z-50 min-w-[200px] animate-fade-in">
                  {sortOptions.map((option) => (
                    <button
                      key={option.value}
                      onClick={() => {
                        setSortBy(option.value);
                        setShowSortDropdown(false);
                      }}
                      className={`w-full text-left px-4 py-2.5 text-sm first:rounded-t-xl last:rounded-b-xl transition-colors ${
                        sortBy === option.value
                          ? 'bg-teal-light text-teal font-medium'
                          : 'text-text-primary hover:bg-gray-50'
                      }`}
                    >
                      {option.label}
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Active category chip */}
            <div className="flex items-center gap-1.5 bg-teal-light text-teal rounded-xl px-3 py-2 text-sm font-medium">
              {(() => {
                const Icon = iconMap[categories.find((c) => c.id === activeCategory)?.icon || 'Wrench'];
                return <Icon size={14} />;
              })()}
              <span className="capitalize">{activeCategory}</span>
            </div>
          </div>
        </div>

        {/* Provider Cards */}
        <div className="px-4 py-4 space-y-4">
          {filteredProviders.map((provider, index) => (
            <ProviderCard
              key={provider.id}
              provider={provider}
              isExpanded={expandedCardId === provider.id}
              onToggle={() =>
                setExpandedCardId(expandedCardId === provider.id ? null : provider.id)
              }
              onBook={() => handleBook(provider)}
              onViewProfile={() => onNavigateToProfile(provider.id)}
              index={index}
            />
          ))}

          {filteredProviders.length === 0 && (
            <div className="flex flex-col items-center justify-center py-16 text-center">
              <Search size={48} className="text-gray-300 mb-4" />
              <p className="text-text-secondary font-medium">No providers found</p>
              <p className="text-text-muted text-sm mt-1">Try adjusting your search or filters</p>
            </div>
          )}
        </div>

        {/* Bottom spacing */}
        <div className="h-24" />
      </div>

      {/* Sticky Bottom Bar */}
      <div
        className={`absolute bottom-16 left-0 right-0 z-30 transition-transform duration-300 ${
          showBottomBar ? 'translate-y-0' : 'translate-y-full'
        }`}
      >
        <div className="mx-4 bg-white rounded-2xl shadow-sticky border border-gray-100 p-4 flex items-center justify-between">
          <div>
            <p className="font-heading font-semibold text-text-primary">Found Top Professionals</p>
            <p className="text-text-secondary text-xs mt-0.5">Best price guaranteed</p>
          </div>
          <button
            onClick={() => {
              if (filteredProviders.length > 0) {
                handleBook(filteredProviders[0]);
              }
            }}
            className="w-10 h-10 rounded-full bg-teal flex items-center justify-center active:scale-95 transition-transform"
          >
            <ArrowRight size={18} className="text-white" />
          </button>
        </div>
      </div>

      {/* Booking Bottom Sheet */}
      {bookingProvider && (
        <BookingSheet
          provider={bookingProvider}
          onClose={() => setBookingProvider(null)}
          onConfirm={handleConfirmBooking}
        />
      )}
    </div>
  );
}
