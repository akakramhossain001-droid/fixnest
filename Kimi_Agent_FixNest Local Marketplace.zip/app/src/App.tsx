import { useState, useCallback } from 'react';
import type { TabName, ScreenName, Booking } from '@/types';
import { initialBookings } from '@/data/providers';
import HomeScreen from '@/screens/HomeScreen';
import ProviderProfileScreen from '@/screens/ProviderProfileScreen';
import BookingsScreen from '@/screens/BookingsScreen';
import ProfileScreen from '@/screens/ProfileScreen';
import BottomNav from '@/components/BottomNav';
import './App.css';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabName>('home');
  const [screenStack, setScreenStack] = useState<ScreenName[]>(['home']);
  const [selectedProviderId, setSelectedProviderId] = useState<string | null>(null);
  const [bookings] = useState<Booking[]>(initialBookings);

  const currentScreen = screenStack[screenStack.length - 1];

  const pushScreen = useCallback((screen: ScreenName, providerId?: string) => {
    if (providerId) setSelectedProviderId(providerId);
    setScreenStack((prev) => [...prev, screen]);
  }, []);

  const popScreen = useCallback(() => {
    setScreenStack((prev) => (prev.length > 1 ? prev.slice(0, -1) : prev));
  }, []);

  const handleNavigateToProfile = useCallback((providerId: string) => {
    pushScreen('providerProfile', providerId);
  }, [pushScreen]);

  const renderScreen = () => {
    switch (currentScreen) {
      case 'home':
        return (
          <HomeScreen
            key="home"
            onNavigateToProfile={handleNavigateToProfile}
          />
        );
      case 'providerProfile':
        return selectedProviderId ? (
          <ProviderProfileScreen
            key={`profile-${selectedProviderId}`}
            providerId={selectedProviderId}
            onBack={popScreen}
          />
        ) : null;
      case 'bookings':
        return <BookingsScreen key="bookings" bookings={bookings} />;
      case 'profile':
        return <ProfileScreen key="profile" />;
      default:
        return null;
    }
  };

  // Map tab to screen
  const handleTabPress = (tab: TabName) => {
    setActiveTab(tab);
    if (tab === 'home') {
      setScreenStack(['home']);
    } else if (tab === 'bookings') {
      setScreenStack(['bookings']);
    } else if (tab === 'profile') {
      setScreenStack(['profile']);
    }
  };

  return (
    <div className="app-container">
      <div className="mobile-frame">
        {/* Main content area */}
        <main className="flex-1 flex flex-col overflow-hidden relative">
          {renderScreen()}
        </main>

        {/* Bottom Navigation - only show on main screens */}
        {screenStack.length === 1 && (
          <BottomNav activeTab={activeTab} onTabChange={handleTabPress} />
        )}
      </div>
    </div>
  );
}
